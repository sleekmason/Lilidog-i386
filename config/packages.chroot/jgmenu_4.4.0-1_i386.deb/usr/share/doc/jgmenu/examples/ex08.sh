#!/bin/sh

jgmenu --vsimple --csv-file=ex08/root

